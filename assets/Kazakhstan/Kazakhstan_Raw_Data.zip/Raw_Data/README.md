# Measurement data for Kazaksthan interception study

This repository contains the following data files:

 - _alexa_100k_domains.txt_ - The Alexa list of domains tested for interception. 
 - _data_over_time.csv_- A summary of median number of TLS hosts affected over time.
 - _domains_targeted.txt_ - All of the domains targeted by the interception. 
 - _kz_certificate_parsed.txt_ - Parsed interception certificate.
 - _kz-intermediate.pem- - Intermediate certificate.
 - _kz_mitm.ips_ - List of TLS hosts experiencing interception during remote measurements from our VPS inside KZ.
 - _kz_ttls.out_ - One of our TTL measurement outputs.
 - _qazca_root.pem_ - Root certificate.
 - _us_mitm.ips_ - List of TLS hosts experiencing interception during remote measurements from the US. 
 - _interception_measurements/_ - Output of our measurements to TLS hosts for 07/19 and 08/19. The interception has since then not been active.
 - _ttl_runs/_ - TTL measurement outputs.

Please contact Ram Sundara Raman (ramaks@umich.edu) and Roya Ensafi (ensafi@umich.edu) with any questions or concerns, or access to more data. 