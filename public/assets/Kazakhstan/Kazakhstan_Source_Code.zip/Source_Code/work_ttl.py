#!/usr/bin/python
#TTL-limited measurements of the Kazakhstan interception system
import socket
import struct
import dpkt
import random
import time
import sys
from threading import Thread

#Client hello for triggered domain
fb_client_hello = '1603010145010001410303f34aebd0312ed809c2c6bb15416016956eb8ed0d3dd060ec652b80f3d6c98c0c0000aac030c02cc028c024c014c00a00a500a300a1009f006b006a0069006800390038003700360088008700860085c032c02ec02ac026c00fc005009d003d00350084c02fc02bc027c023c013c00900a400a200a0009e00670040003f003e0033003200310030009a0099009800970045004400430042c031c02dc029c025c00ec004009c003c002f00960041c011c007c00cc00200050004c012c008001600130010000dc00dc003000a00ff0100006e0000001500130000107777772e66616365626f6f6b2e636f6d000b000403000102000a001c001a00170019001c001b0018001a0016000e000d000b000c0009000a00230000000d0020001e060106020603050105020503040104020403030103020303020102020203000f000101'.decode('hex')

#Client hello for normal domain
norm_client_hello = '160301012c0100012803032f2286ff3593b744d4c246e897b88b3e6f03954a3258fdbb2b296242805ad4db0000aac030c02cc028c024c014c00a00a500a300a1009f006b006a0069006800390038003700360088008700860085c032c02ec02ac026c00fc005009d003d00350084c02fc02bc027c023c013c00900a400a200a0009e00670040003f003e0033003200310030009a0099009800970045004400430042c031c02dc029c025c00ec004009c003c002f00960041c011c007c00cc00200050004c012c008001600130010000dc00dc003000a00ff01000055000b000403000102000a001c001a00170019001c001b0018001a0016000e000d000b000c0009000a00230000000d0020001e060106020603050105020503040104020403030103020303020102020203000f000101'.decode('hex')


# UPDATE THESE:
# Make sure you prevent your OS from sending RSTS:
# iptables -A OUTPUT -p tcp --tcp-flags RST RST -j DROP

IFACE='enp1s0f1'
server_ip = sys.argv[1].replace('"','')
#enter your client's IP address here
client_ip = ''

print("Testing " + server_ip)
#icmps = {}  # server_ip => {hop => hop_ip}

# If you need a background thread watching icmp..
#def get_icmps():
#    s = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.IPPROTO_IP) #3 = ETH_P_ALL
#    s.bind((IFACE, 3))
#    while True:
#        try:
#            pkt = s.recv(0xffff)
#            eth = dpkt.ethernet.Ethernet(pkt)
#            ip = eth.data
#            if ip.p == dpkt.ip.IP_PROTO_ICMP:
#                print 'ICMP...', ip.__repr__()
#        except:
#            continue
#
#thread = Thread(target = get_icmps, args = ())
#thread.start()


# This function returns a tuple of dpkt.ip packet (or None if timeout)
# and a dpkt.ip.icmp packet that occurred
def get_pkt(s=None, src_ip=None, src_port=None, timeout=2):
    if s is None:
        s = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.IPPROTO_IP) #3 = ETH_P_ALL
        s.bind((IFACE, 3))

    #s.bind((IFACE, 3))
    start = time.time()
    icmp_pkt = None

    while (time.time() - start) < timeout:
        try:
            pkt = s.recv(0xffff)
            eth = dpkt.ethernet.Ethernet(pkt)
            ip = eth.data
            # if ICMP, put it in the table...TBD
            if ip.p == dpkt.ip.IP_PROTO_ICMP:
                #print 'ICMP   ', ip.__repr__()
                icmp_pkt = ip

            # TCP only
            if ip.p != dpkt.ip.IP_PROTO_TCP:
                continue
            if (src_ip is None or src_ip == ip.src) and (src_port is None or src_port == ip.data.dport):
                return ip, icmp_pkt
        except:
            continue
        if ip.p == dpkt.ip.IP_PROTO_TCP:
            pass
            #print 'Not it: ', ip.__repr__()

    return (None, icmp_pkt)

#This packet performs the TCP handshake and sends the limited Client Hellos
def get_resp_hop(server_ip, client_hello):

    s_port = random.randint(10000, 40000)
    isn = 123456789

    sockfd = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_RAW)
    sockfd.setsockopt(socket.IPPROTO_IP, socket.IP_HDRINCL, True)

    raw_sock = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.IPPROTO_IP) #3 = ETH_P_ALL
    raw_sock.bind((IFACE, 3))

    # Send SYN
    syn = dpkt.ip.IP(src=socket.inet_aton(client_ip), dst=socket.inet_aton(server_ip), \
                     p=dpkt.ip.IP_PROTO_TCP, ttl=64, \
                     data=dpkt.tcp.TCP(sport=s_port, dport=443, seq=isn, ack=0, \
                                       flags=dpkt.tcp.TH_SYN))
    sockfd.sendto(str(syn), (server_ip, 443))
    start = time.time()
    print 'Sent SYN to %s...' % (server_ip)

    # Get SYN-ACK
    resp, _ = get_pkt(s=raw_sock, src_ip=socket.inet_aton(server_ip), src_port=s_port)
    rtt = time.time()-start
    if resp is None:
        print 'Error: no response from %s' % (server_ip)
        return None
    print 'Got SYN-ACK for %s in %.03f ms: %s' % (server_ip, 1000*(rtt), resp.__repr__())

    # Send ACK
    ack_n = resp.data.seq + 1
    ack = dpkt.ip.IP(src=socket.inet_aton(client_ip), dst=socket.inet_aton(server_ip), \
                     p=dpkt.ip.IP_PROTO_TCP, ttl=64, \
                     data=dpkt.tcp.TCP(sport=s_port, dport=443, seq=isn+1, ack=ack_n, \
                                       flags=dpkt.tcp.TH_ACK))
    sockfd.sendto(str(ack), (server_ip, 443))


    # Get a Client Hello IP pkt with a specific IP TTL
    def get_chello(ttl=64):
        tls = dpkt.ip.IP(src=socket.inet_aton(client_ip), dst=socket.inet_aton(server_ip), \
                         p=dpkt.ip.IP_PROTO_TCP, ttl=ttl,
                         data=dpkt.tcp.TCP(sport=s_port, dport=443, seq=isn+1, ack=ack_n, \
                                           flags=dpkt.tcp.TH_ACK|dpkt.tcp.TH_PUSH, data=client_hello))
        return tls


    hops = []
    for ttl in range(1, 64):

        print 'Sending TLS Client Hello to %s with TTL %d...' % (server_ip, ttl)
        sockfd.sendto(str(get_chello(ttl)), (server_ip, 443))
        try:
            resp, icmp_pkt = get_pkt(s=raw_sock, src_ip=socket.inet_aton(server_ip), src_port=s_port, timeout=2.5*rtt)
        except:
            continue
        hop_ip = '*'
        if icmp_pkt is not None:
            hop_ip = socket.inet_ntoa(icmp_pkt.src)
        hops.append(hop_ip)

        if resp is not None:
            print 'Response from %s after %.03f ms: %s' % \
                    (server_ip, 1000*(time.time()-start), resp.__repr__())
	    print '# %s %d' % (server_ip, ttl)
            print '\n!'.join(['   %d  %s' % (hop, ip) for hop,ip in enumerate(hops,1)])
            return ttl, hops
            break

    return None

try:
    fb_hop, hops = get_resp_hop(server_ip, fb_client_hello)
    norm_hop, hops = get_resp_hop(server_ip, norm_client_hello)
    if norm_hop != fb_hop and server_ip != hops[fb_hop-1]:
        print '### %s    %d   %d  @%s' % (server_ip, norm_hop, fb_hop, hops[fb_hop-1])
except:
    print '-1'



