#!/bin/bash
#Code to run ZGrab for the affected domains to the TLS hosts in Kazakhstan with valid browser trusted certificates
#Get the affected domains
input="/kazakhstan/domains.txt"
userpath="/home/ram"
TIMESTAMP=$(date +%Y-%m-%dT%H:%M:%S)
while IFS= read -r line
do
	fname="$TIMESTAMP-$line"
	#Run ZGrab2
	cat $userpath/kazakhstan/data/20190721_kz_validtls_ips | $userpath/kazakhstan/zgrab2 tls --server-name=$line | grep "Qaznet Trust Network" | jq .ip | sort -n >> $userpath/kazakhstan/data/runs/$fname
done < "$input"
#Get data for the live page
wc -l  $userpath/kazakhstan/data/runs/$TIMESTAMP* | awk -F '[ -]' '{print $3,$7}' > $userpath/kazakhstan/data/current_num_servers
#datapath=$userpath/kazakhstan/data/
#cd $datapath

#Push to git
#git pull
#git add current_num_servers
#git commit -m "10 minute update"
#git push
