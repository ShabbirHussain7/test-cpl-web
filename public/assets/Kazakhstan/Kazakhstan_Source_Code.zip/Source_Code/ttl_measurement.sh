#!/bin/bash
#Code to run the TTL-limited measurements continously on the latest data
TIMESTAMP=$(date +%Y-%m-%dT%H:%M:%S)
userpath="/home/ram"
fname="$TIMESTAMP-ttl_output"
#Get the data from the latest run
find $userpath/kazakhstan/data/runs/ -type f -printf '%T@ %p\n' | sort -n | tail -6 | head -1 | cut -f2- -d" " > $userpath/kazakhstan/data/latest_file.txt
input="$userpath/kazakhstan/data/latest_file.txt"
while IFS= read -r line
do
	input_2=$line
done < "$input"
echo $input_2
#Change iptables
iptables -A OUTPUT -p tcp --tcp-flags RST RST -j DROP
while IFS= read -r line
do
	echo $line
	#Call the work_ttl code
	time python work_ttl.py $line >> $userpath/kazakhstan/data/ttl_runs/$fname
done < "$input_2"
