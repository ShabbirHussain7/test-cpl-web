# Source Code for Kazaksthan interception study

This repository contains the following files (make sure to change the userpath for all of them before using):

 - _tls_hosts_measurement.sh_ - This script runs ZGrab2 on all of the TLS hosts with valid browser trusted certificates in Kazakhstan with the provided domains to check if there is sign of the interception certificate. The list of TLS host IPs must be provided and can be obtained from [Censys](https://censys.io).
 - _alexa_measurement.sh_- Test all of the Alexa Top 100,000 domains using ZGrab2 on all of the TLS hosts in Kazakhstan.
 - _work_ttl.py_ - Runs TTL-limited measurements to TLS hosts in Kazakhstan. Once the TCP handshake is complete, two ClientHellos are sent with incrementing TTL, one for an unaffected domain and one for an affected domain (facebook.com). The client IP address must be provided. 
 - _ttl_mreasurement.sh_ - Wrapper for _work_ttl.py_.
 - _get_data_over_time.rb_ - Given all of the longitudinal runs, calculates the median number of affected TLS hosts for every run.

Some of the data acquired from the above scripts during the interception are also made available [on our website](https://censoredplanet.org/Kazakhstan_Raw_Data.zip). Please contact Ram Sundara Raman (ramaks@umich.edu) and Roya Ensafi (ensafi@umich.edu) with any questions or concerns. 