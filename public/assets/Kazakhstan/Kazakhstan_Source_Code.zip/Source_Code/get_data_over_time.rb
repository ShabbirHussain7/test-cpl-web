
date_hash = Hash.new{|hash,key| hash[key] = Array.new}
files = Dir.glob(ARGV[0])
def median(array)
  sorted = array.sort
  len = sorted.length
  (sorted[(len - 1) / 2] + sorted[len / 2]) / 2.0
end
files.each do |file|
	fname = file.split('/')[-1]
	date = fname.split('-')[0].to_s + '-' + fname.split('-')[1].to_s + '-' + fname.split('-')[2].to_s
	fp = File.open(file)
	count = 0
	fp.each_line do |line|
		count += 1
	end
	date_hash[date] << count
end
op_hash = Hash.new
date_hash.each do |date,arr|
	op_hash[date] = median(arr)
end
op_hash.each do |date,count|
	puts date.to_s + ',' + count.to_s
end
