#!/bin/bash
input="/kazakhstan/dom.txt"
TIMESTAMP=$(date +%Y-%m-%dT%H:%M:%S)
userpath="/home/ram"
while IFS= read -r line
do
	fname="$TIMESTAMP-$line"
cat $userpath/kazakhstan/data/20190721_kz_validtls_ips | $userpath/kazakhstan/zgrab2 tls --server-name=$line | grep "Qaznet Trust Network" | jq .ip | sort -n > $userpath/kazakhstan/data/alexa_domains_blocked
linecnt=$( cat $userpath/kazakhstan/data/alexa_domains_blocked | wc -l )
echo $linecount
file="$TIMESTAMP-alexa_num_domains_blocked"
if [[ $linecnt -gt 0 ]] ; then
  echo $line >> $userpath/kazakhstan/data/alexa_runs/$file
  echo $line >> $userpath/kazakhstan/data/alexa_domains_ever_blocked
fi

done < "$input"
cp $userpath/kazakhstan/data/alexa_runs/$file $userpath/kazakhstan/data/alexa_num_domains_blocked